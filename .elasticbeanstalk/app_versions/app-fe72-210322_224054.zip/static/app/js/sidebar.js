// window.onload = function(){
// 	let sidebarswitch = document.getElementById('accordionSidebar');
// 	sidebarswitch.classList.add("toggled");
// };