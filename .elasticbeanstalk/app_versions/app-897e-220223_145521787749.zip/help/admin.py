from django.contrib import admin
from .models import Tutorial,Calldetail

admin.site.register(Tutorial)
admin.site.register(Calldetail)

