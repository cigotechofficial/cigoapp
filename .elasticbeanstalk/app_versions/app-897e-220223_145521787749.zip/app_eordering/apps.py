from django.apps import AppConfig


class App_eorderingConfig(AppConfig):
    name = 'app_eordering'
