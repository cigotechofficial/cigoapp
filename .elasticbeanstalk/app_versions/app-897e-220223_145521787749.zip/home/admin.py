from django.contrib import admin
from .models import Gst,Newuserinfo,Defaultimg,Contactus

admin.site.register(Gst)
admin.site.register(Newuserinfo)
admin.site.register(Defaultimg)
admin.site.register(Contactus)
