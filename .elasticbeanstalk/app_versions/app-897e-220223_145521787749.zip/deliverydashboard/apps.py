from django.apps import AppConfig


class DeliverydashboardConfig(AppConfig):
    name = 'deliverydashboard'
