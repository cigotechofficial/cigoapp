  function actionToggle() {
    var action = document.querySelector('.action');
    action.classList.toggle('active')
}