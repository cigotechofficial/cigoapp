from django.apps import AppConfig


class App_emenuConfig(AppConfig):
    name = 'app_emenu'
