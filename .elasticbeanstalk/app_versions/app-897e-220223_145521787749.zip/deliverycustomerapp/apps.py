from django.apps import AppConfig


class DeliverycustomerappConfig(AppConfig):
    name = 'deliverycustomerapp'
